// Copyright 2025 Lihan Chen
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "pb_omni_pid_pursuit_controller/omni_mpc_pursuit_controller.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <sstream>
#include <utility>

#include "nav2_core/exceptions.hpp"
#include "nav2_costmap_2d/cost_values.hpp"
#include "nav2_util/geometry_utils.hpp"
#include "nav2_util/node_utils.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/exceptions.h"
#include "tf2/utils.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"

using nav2_util::declare_parameter_if_not_declared;
using nav2_util::geometry_utils::euclidean_distance;

namespace pb_omni_pid_pursuit_controller
{

void OmniMpcPursuitController::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent, std::string name,
  std::shared_ptr<tf2_ros::Buffer> tf, std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  auto node = parent.lock();
  node_ = parent;
  if (!node) {
    throw nav2_core::PlannerException("Unable to lock node!");
  }

  tf_ = tf;
  costmap_ros_ = costmap_ros;
  costmap_ = costmap_ros_->getCostmap();
  plugin_name_ = name;
  logger_ = node->get_logger();
  clock_ = node->get_clock();

  declare_parameter_if_not_declared(
    node, plugin_name_ + ".transform_tolerance", rclcpp::ParameterValue(0.2));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".horizon_steps", rclcpp::ParameterValue(12));
  declare_parameter_if_not_declared(node, plugin_name_ + ".model_dt", rclcpp::ParameterValue(0.05));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".reference_speed", rclcpp::ParameterValue(0.8));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".lookahead_dist", rclcpp::ParameterValue(0.8));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".max_robot_pose_search_dist", rclcpp::ParameterValue(3.0));

  declare_parameter_if_not_declared(node, plugin_name_ + ".vx_min", rclcpp::ParameterValue(-0.2));
  declare_parameter_if_not_declared(node, plugin_name_ + ".vx_max", rclcpp::ParameterValue(1.2));
  declare_parameter_if_not_declared(node, plugin_name_ + ".vy_min", rclcpp::ParameterValue(-0.45));
  declare_parameter_if_not_declared(node, plugin_name_ + ".vy_max", rclcpp::ParameterValue(0.45));
  declare_parameter_if_not_declared(node, plugin_name_ + ".wz_min", rclcpp::ParameterValue(-2.2));
  declare_parameter_if_not_declared(node, plugin_name_ + ".wz_max", rclcpp::ParameterValue(2.2));

  declare_parameter_if_not_declared(node, plugin_name_ + ".ax_max", rclcpp::ParameterValue(2.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".ay_max", rclcpp::ParameterValue(2.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".az_max", rclcpp::ParameterValue(3.0));

  declare_parameter_if_not_declared(node, plugin_name_ + ".vx_samples", rclcpp::ParameterValue(7));
  declare_parameter_if_not_declared(node, plugin_name_ + ".vy_samples", rclcpp::ParameterValue(7));
  declare_parameter_if_not_declared(node, plugin_name_ + ".wz_samples", rclcpp::ParameterValue(9));

  declare_parameter_if_not_declared(node, plugin_name_ + ".q_path_x", rclcpp::ParameterValue(2.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".q_path_y", rclcpp::ParameterValue(12.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".q_yaw", rclcpp::ParameterValue(6.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".q_terminal", rclcpp::ParameterValue(3.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".r_control", rclcpp::ParameterValue(0.2));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".r_delta_control", rclcpp::ParameterValue(2.0));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".collision_check_step", rclcpp::ParameterValue(2));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".use_minco_trajectory", rclcpp::ParameterValue(true));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".trajectory_timeout", rclcpp::ParameterValue(0.3));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".max_solve_time_ms", rclcpp::ParameterValue(20.0));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".fallback_to_path_mpc", rclcpp::ParameterValue(true));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_vx", rclcpp::ParameterValue(1.2));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_vy", rclcpp::ParameterValue(0.45));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_wz", rclcpp::ParameterValue(2.2));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_ax", rclcpp::ParameterValue(2.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_ay", rclcpp::ParameterValue(2.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_awz", rclcpp::ParameterValue(3.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".max_jerk", rclcpp::ParameterValue(8.0));
  declare_parameter_if_not_declared(node, plugin_name_ + ".q_velocity", rclcpp::ParameterValue(0.8));
  declare_parameter_if_not_declared(
    node, plugin_name_ + ".minco_sample_dt", rclcpp::ParameterValue(0.05));

  double transform_tolerance = 0.2;
  node->get_parameter(plugin_name_ + ".transform_tolerance", transform_tolerance);
  node->get_parameter(plugin_name_ + ".horizon_steps", horizon_steps_);
  node->get_parameter(plugin_name_ + ".model_dt", model_dt_);
  node->get_parameter(plugin_name_ + ".reference_speed", reference_speed_);
  node->get_parameter(plugin_name_ + ".lookahead_dist", lookahead_dist_);
  node->get_parameter(plugin_name_ + ".max_robot_pose_search_dist", max_robot_pose_search_dist_);
  node->get_parameter(plugin_name_ + ".vx_min", vx_min_);
  node->get_parameter(plugin_name_ + ".vx_max", vx_max_);
  node->get_parameter(plugin_name_ + ".vy_min", vy_min_);
  node->get_parameter(plugin_name_ + ".vy_max", vy_max_);
  node->get_parameter(plugin_name_ + ".wz_min", wz_min_);
  node->get_parameter(plugin_name_ + ".wz_max", wz_max_);
  node->get_parameter(plugin_name_ + ".ax_max", ax_max_);
  node->get_parameter(plugin_name_ + ".ay_max", ay_max_);
  node->get_parameter(plugin_name_ + ".az_max", az_max_);
  node->get_parameter(plugin_name_ + ".vx_samples", vx_samples_);
  node->get_parameter(plugin_name_ + ".vy_samples", vy_samples_);
  node->get_parameter(plugin_name_ + ".wz_samples", wz_samples_);
  node->get_parameter(plugin_name_ + ".q_path_x", q_path_x_);
  node->get_parameter(plugin_name_ + ".q_path_y", q_path_y_);
  node->get_parameter(plugin_name_ + ".q_yaw", q_yaw_);
  node->get_parameter(plugin_name_ + ".q_terminal", q_terminal_);
  node->get_parameter(plugin_name_ + ".r_control", r_control_);
  node->get_parameter(plugin_name_ + ".r_delta_control", r_delta_control_);
  node->get_parameter(plugin_name_ + ".collision_check_step", collision_check_step_);
  node->get_parameter(plugin_name_ + ".use_minco_trajectory", use_minco_trajectory_);
  node->get_parameter(plugin_name_ + ".trajectory_timeout", trajectory_timeout_);
  node->get_parameter(plugin_name_ + ".max_solve_time_ms", max_solve_time_ms_);
  node->get_parameter(plugin_name_ + ".fallback_to_path_mpc", fallback_to_path_mpc_);
  node->get_parameter(plugin_name_ + ".max_vx", max_vx_);
  node->get_parameter(plugin_name_ + ".max_vy", max_vy_);
  node->get_parameter(plugin_name_ + ".max_wz", max_wz_);
  node->get_parameter(plugin_name_ + ".max_ax", max_ax_);
  node->get_parameter(plugin_name_ + ".max_ay", max_ay_);
  node->get_parameter(plugin_name_ + ".max_awz", max_awz_);
  node->get_parameter(plugin_name_ + ".max_jerk", max_jerk_);
  node->get_parameter(plugin_name_ + ".q_velocity", q_velocity_);
  node->get_parameter(plugin_name_ + ".minco_sample_dt", minco_sample_dt_);

  double controller_frequency = 20.0;
  node->get_parameter("controller_frequency", controller_frequency);
  control_duration_ = controller_frequency > 0.0 ? 1.0 / controller_frequency : model_dt_;

  horizon_steps_ = std::max(1, horizon_steps_);
  model_dt_ = std::max(0.01, model_dt_);
  reference_speed_ = std::max(0.0, reference_speed_);
  lookahead_dist_ = std::max(0.05, lookahead_dist_);
  max_robot_pose_search_dist_ = std::max(0.1, max_robot_pose_search_dist_);
  ax_max_ = std::max(0.01, std::abs(ax_max_));
  ay_max_ = std::max(0.01, std::abs(ay_max_));
  az_max_ = std::max(0.01, std::abs(az_max_));
  vx_samples_ = std::max(1, vx_samples_);
  vy_samples_ = std::max(1, vy_samples_);
  wz_samples_ = std::max(1, wz_samples_);
  collision_check_step_ = std::max(1, collision_check_step_);
  trajectory_timeout_ = std::max(0.0, trajectory_timeout_);
  max_solve_time_ms_ = std::max(0.1, max_solve_time_ms_);
  max_vx_ = std::max(0.01, std::abs(max_vx_));
  max_vy_ = std::max(0.01, std::abs(max_vy_));
  max_wz_ = std::max(0.01, std::abs(max_wz_));
  max_ax_ = std::max(0.01, std::abs(max_ax_));
  max_ay_ = std::max(0.01, std::abs(max_ay_));
  max_awz_ = std::max(0.01, std::abs(max_awz_));
  max_jerk_ = std::max(0.01, std::abs(max_jerk_));
  vx_max_ = std::min(vx_max_, max_vx_);
  vx_min_ = std::max(vx_min_, -max_vx_);
  vy_max_ = std::min(vy_max_, max_vy_);
  vy_min_ = std::max(vy_min_, -max_vy_);
  wz_max_ = std::min(wz_max_, max_wz_);
  wz_min_ = std::max(wz_min_, -max_wz_);
  ax_max_ = std::min(ax_max_, max_ax_);
  ay_max_ = std::min(ay_max_, max_ay_);
  az_max_ = std::min(az_max_, max_awz_);
  minco_sample_dt_ = clampValue(minco_sample_dt_, 0.01, 0.2);
  transform_tolerance_ = tf2::durationFromSec(transform_tolerance);

  minco_trajectory_path_pub_ =
    node->create_publisher<nav_msgs::msg::Path>("/minco_trajectory_path", rclcpp::SystemDefaultsQoS());
  minco_trajectory_markers_pub_ =
    node->create_publisher<visualization_msgs::msg::MarkerArray>(
      "/minco_trajectory_markers", rclcpp::SystemDefaultsQoS());
  minco_debug_pub_ =
    node->create_publisher<std_msgs::msg::String>("/minco_debug", rclcpp::SystemDefaultsQoS());

  RCLCPP_INFO(
    logger_,
    "Configured Omni MPC pursuit controller %s with horizon %d x %.3fs, timed trajectory: %s",
    plugin_name_.c_str(), horizon_steps_, model_dt_, use_minco_trajectory_ ? "enabled" : "disabled");
}

void OmniMpcPursuitController::cleanup()
{
  minco_trajectory_path_pub_.reset();
  minco_trajectory_markers_pub_.reset();
  minco_debug_pub_.reset();
  RCLCPP_INFO(logger_, "Cleaning up controller: %s", plugin_name_.c_str());
}

void OmniMpcPursuitController::activate()
{
  last_cmd_ = Command{};
  have_last_cmd_ = false;
  if (minco_trajectory_path_pub_) {
    minco_trajectory_path_pub_->on_activate();
  }
  if (minco_trajectory_markers_pub_) {
    minco_trajectory_markers_pub_->on_activate();
  }
  if (minco_debug_pub_) {
    minco_debug_pub_->on_activate();
  }
  RCLCPP_INFO(logger_, "Activating controller: %s", plugin_name_.c_str());
}

void OmniMpcPursuitController::deactivate()
{
  last_cmd_ = Command{};
  have_last_cmd_ = false;
  if (minco_trajectory_path_pub_) {
    minco_trajectory_path_pub_->on_deactivate();
  }
  if (minco_trajectory_markers_pub_) {
    minco_trajectory_markers_pub_->on_deactivate();
  }
  if (minco_debug_pub_) {
    minco_debug_pub_->on_deactivate();
  }
  RCLCPP_INFO(logger_, "Deactivating controller: %s", plugin_name_.c_str());
}

geometry_msgs::msg::TwistStamped OmniMpcPursuitController::computeVelocityCommands(
  const geometry_msgs::msg::PoseStamped & pose, const geometry_msgs::msg::Twist & velocity,
  nav2_core::GoalChecker * /*goal_checker*/)
{
  std::lock_guard<std::mutex> lock(mutex_);

  auto * costmap = costmap_ros_->getCostmap();
  std::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> costmap_lock(*(costmap->getMutex()));

  nav_msgs::msg::Path transformed_plan;
  try {
    transformed_plan = transformGlobalPlan(pose);
  } catch (const std::exception & ex) {
    RCLCPP_WARN_THROTTLE(
      logger_, *clock_, 1000, "MPC cannot transform plan yet: %s. Commanding zero velocity.",
      ex.what());
    last_cmd_ = Command{};
    have_last_cmd_ = true;
    return makeZeroCommand(pose);
  }

  const auto build_start = std::chrono::steady_clock::now();
  bool timed_trajectory_valid = false;
  std::vector<TrajectoryPoint> timed_trajectory;
  if (use_minco_trajectory_) {
    timed_trajectory = buildTimedTrajectory(transformed_plan, timed_trajectory_valid);
  }
  const auto build_end = std::chrono::steady_clock::now();
  const double build_ms =
    std::chrono::duration<double, std::milli>(build_end - build_start).count();
  if (timed_trajectory_valid && trajectory_timeout_ > 0.0 && build_ms * 0.001 > trajectory_timeout_) {
    RCLCPP_WARN_THROTTLE(
      logger_, *clock_, 1000,
      "Timed trajectory generation exceeded trajectory_timeout %.3fs. Falling back to path MPC.",
      trajectory_timeout_);
    timed_trajectory_valid = false;
    timed_trajectory.clear();
  }

  const std::vector<TrajectoryPoint> * trajectory_ptr =
    use_minco_trajectory_ && timed_trajectory_valid ? &timed_trajectory : nullptr;
  bool fallback = false;
  if (use_minco_trajectory_ && trajectory_ptr == nullptr) {
    if (!fallback_to_path_mpc_) {
      RCLCPP_WARN_THROTTLE(
        logger_, *clock_, 1000,
        "Timed trajectory generation failed and fallback_to_path_mpc is false. Commanding zero.");
      last_cmd_ = Command{};
      have_last_cmd_ = true;
      publishDebug("zero", false, false, build_ms, 0.0, 0);
      return makeZeroCommand(pose);
    }
    fallback = true;
  }

  const auto solve_start = std::chrono::steady_clock::now();
  bool solve_timed_out = false;
  auto command = chooseBestCommand(transformed_plan, velocity, trajectory_ptr, solve_timed_out);
  const auto solve_end = std::chrono::steady_clock::now();
  const double solve_ms =
    std::chrono::duration<double, std::milli>(solve_end - solve_start).count();

  if (trajectory_ptr != nullptr) {
    publishTimedTrajectory(*trajectory_ptr, transformed_plan.header);
    publishTrajectoryMarkers(*trajectory_ptr, transformed_plan.header);
  }
  publishDebug(
    trajectory_ptr != nullptr ? "timed_trajectory_mpc" : "path_mpc", fallback, solve_timed_out,
    build_ms, solve_ms, trajectory_ptr != nullptr ? trajectory_ptr->size() : 0);

  last_cmd_ = command;
  have_last_cmd_ = true;
  return makeCommandMsg(pose, command);
}

void OmniMpcPursuitController::setPlan(const nav_msgs::msg::Path & path)
{
  std::lock_guard<std::mutex> lock(mutex_);
  global_plan_ = path;
}

void OmniMpcPursuitController::setSpeedLimit(
  const double & /*speed_limit*/, const bool & /*percentage*/)
{
  RCLCPP_WARN_THROTTLE(
    logger_, *clock_, 5000, "Speed limit is not implemented in OmniMpcPursuitController.");
}

nav_msgs::msg::Path OmniMpcPursuitController::transformGlobalPlan(
  const geometry_msgs::msg::PoseStamped & pose)
{
  if (global_plan_.poses.empty()) {
    throw nav2_core::PlannerException("Received plan with zero length");
  }

  geometry_msgs::msg::PoseStamped robot_pose;
  if (!transformPose(global_plan_.header.frame_id, pose, robot_pose)) {
    throw nav2_core::PlannerException("Unable to transform robot pose into global plan's frame");
  }

  const double max_costmap_extent = getCostmapMaxExtent();
  auto closest_pose_upper_bound = nav2_util::geometry_utils::first_after_integrated_distance(
    global_plan_.poses.begin(), global_plan_.poses.end(), max_robot_pose_search_dist_);

  auto transformation_begin = nav2_util::geometry_utils::min_by(
    global_plan_.poses.begin(), closest_pose_upper_bound,
    [&robot_pose](const geometry_msgs::msg::PoseStamped & ps) {
      return euclidean_distance(robot_pose, ps);
    });

  if (transformation_begin == global_plan_.poses.end()) {
    throw nav2_core::PlannerException("Cannot find closest pose on global plan");
  }

  auto transformation_end = std::find_if(
    transformation_begin, global_plan_.poses.end(),
    [&](const auto & path_pose) {
      return euclidean_distance(path_pose, robot_pose) > max_costmap_extent;
    });

  if (transformation_end == transformation_begin) {
    transformation_end = std::next(transformation_begin);
  }

  auto transform_global_pose_to_local = [&](const auto & global_plan_pose) {
    geometry_msgs::msg::PoseStamped stamped_pose;
    geometry_msgs::msg::PoseStamped transformed_pose;
    stamped_pose.header.frame_id = global_plan_.header.frame_id;
    stamped_pose.header.stamp = robot_pose.header.stamp;
    stamped_pose.pose = global_plan_pose.pose;
    if (!transformPose(costmap_ros_->getBaseFrameID(), stamped_pose, transformed_pose)) {
      throw nav2_core::PlannerException("Unable to transform path pose into robot frame");
    }
    transformed_pose.pose.position.z = 0.0;
    return transformed_pose;
  };

  nav_msgs::msg::Path transformed_plan;
  std::transform(
    transformation_begin, transformation_end, std::back_inserter(transformed_plan.poses),
    transform_global_pose_to_local);
  transformed_plan.header.frame_id = costmap_ros_->getBaseFrameID();
  transformed_plan.header.stamp = robot_pose.header.stamp;

  global_plan_.poses.erase(global_plan_.poses.begin(), transformation_begin);

  if (transformed_plan.poses.empty()) {
    throw nav2_core::PlannerException("Resulting plan has 0 poses in it.");
  }

  return transformed_plan;
}

bool OmniMpcPursuitController::transformPose(
  const std::string & frame, const geometry_msgs::msg::PoseStamped & in_pose,
  geometry_msgs::msg::PoseStamped & out_pose) const
{
  if (in_pose.header.frame_id == frame) {
    out_pose = in_pose;
    return true;
  }

  try {
    tf_->transform(in_pose, out_pose, frame, transform_tolerance_);
    return true;
  } catch (tf2::TransformException & ex) {
    RCLCPP_WARN_THROTTLE(logger_, *clock_, 1000, "Exception in transformPose: %s", ex.what());
  }
  return false;
}

double OmniMpcPursuitController::getCostmapMaxExtent() const
{
  const double max_costmap_dim_meters =
    std::max(costmap_->getSizeInMetersX(), costmap_->getSizeInMetersY());
  return max_costmap_dim_meters / 2.0;
}

std::vector<double> OmniMpcPursuitController::calculateCumulativeDistances(
  const nav_msgs::msg::Path & path) const
{
  std::vector<double> distances;
  distances.reserve(path.poses.size());
  distances.push_back(0.0);
  for (size_t i = 1; i < path.poses.size(); ++i) {
    const auto & prev = path.poses[i - 1].pose.position;
    const auto & curr = path.poses[i].pose.position;
    distances.push_back(distances.back() + std::hypot(curr.x - prev.x, curr.y - prev.y));
  }
  return distances;
}

OmniMpcPursuitController::Reference OmniMpcPursuitController::getReferenceAtDistance(
  const nav_msgs::msg::Path & path, const std::vector<double> & cumulative_distances,
  double target_distance) const
{
  if (path.poses.size() == 1) {
    const auto & pose = path.poses.front().pose;
    return {pose.position.x, pose.position.y, tf2::getYaw(pose.orientation)};
  }

  if (target_distance <= 0.0) {
    return makeReferenceFromSegment(path.poses[0], path.poses[1], 0.0);
  }

  for (size_t i = 1; i < path.poses.size(); ++i) {
    if (cumulative_distances[i] >= target_distance) {
      const double segment_length = cumulative_distances[i] - cumulative_distances[i - 1];
      const double ratio = segment_length > 1.0e-6
                             ? (target_distance - cumulative_distances[i - 1]) / segment_length
                             : 1.0;
      return makeReferenceFromSegment(path.poses[i - 1], path.poses[i], clampValue(ratio, 0.0, 1.0));
    }
  }

  return makeReferenceFromSegment(
    path.poses[path.poses.size() - 2], path.poses[path.poses.size() - 1], 1.0);
}

OmniMpcPursuitController::Reference OmniMpcPursuitController::makeReferenceFromSegment(
  const geometry_msgs::msg::PoseStamped & start, const geometry_msgs::msg::PoseStamped & end,
  double ratio) const
{
  const auto & p0 = start.pose.position;
  const auto & p1 = end.pose.position;
  const double x = p0.x + ratio * (p1.x - p0.x);
  const double y = p0.y + ratio * (p1.y - p0.y);
  const double dx = p1.x - p0.x;
  const double dy = p1.y - p0.y;
  const double yaw = std::hypot(dx, dy) > 1.0e-6 ? std::atan2(dy, dx) : tf2::getYaw(end.pose.orientation);
  return {x, y, yaw};
}

OmniMpcPursuitController::Reference OmniMpcPursuitController::getSmoothedReferenceAtDistance(
  const nav_msgs::msg::Path & path, const std::vector<double> & cumulative_distances,
  double target_distance, double reference_speed) const
{
  if (path.poses.size() == 1) {
    const auto & pose = path.poses.front().pose;
    return {pose.position.x, pose.position.y, tf2::getYaw(pose.orientation)};
  }

  if (target_distance <= 0.0) {
    return makeSmoothedReferenceFromSegment(path, cumulative_distances, 1, 0.0, reference_speed);
  }

  for (size_t i = 1; i < path.poses.size(); ++i) {
    if (cumulative_distances[i] >= target_distance) {
      const double segment_length = cumulative_distances[i] - cumulative_distances[i - 1];
      const double ratio = segment_length > 1.0e-6
                             ? (target_distance - cumulative_distances[i - 1]) / segment_length
                             : 1.0;
      return makeSmoothedReferenceFromSegment(
        path, cumulative_distances, i, clampValue(ratio, 0.0, 1.0), reference_speed);
    }
  }

  return makeSmoothedReferenceFromSegment(
    path, cumulative_distances, path.poses.size() - 1, 1.0, reference_speed);
}

OmniMpcPursuitController::Reference OmniMpcPursuitController::makeSmoothedReferenceFromSegment(
  const nav_msgs::msg::Path & path, const std::vector<double> & cumulative_distances,
  size_t segment_index, double ratio, double reference_speed) const
{
  const size_t i1 = std::min(segment_index, path.poses.size() - 1);
  const size_t i0 = i1 > 0 ? i1 - 1 : 0;
  const size_t im1 = i0 > 0 ? i0 - 1 : i0;
  const size_t ip1 = std::min(i1 + 1, path.poses.size() - 1);

  const auto & p0 = path.poses[i0].pose.position;
  const auto & p1 = path.poses[i1].pose.position;
  const auto & pm1 = path.poses[im1].pose.position;
  const auto & pp1 = path.poses[ip1].pose.position;

  const double segment_length =
    std::max(1.0e-6, cumulative_distances[i1] - cumulative_distances[i0]);
  const double u = clampValue(ratio, 0.0, 1.0);
  const double u2 = u * u;
  const double u3 = u2 * u;

  auto normalized = [](double x, double y) {
      const double norm = std::hypot(x, y);
      if (norm < 1.0e-6) {
        return std::pair<double, double>{1.0, 0.0};
      }
      return std::pair<double, double>{x / norm, y / norm};
    };

  const auto t0 = normalized(p1.x - pm1.x, p1.y - pm1.y);
  const auto t1 = normalized(pp1.x - p0.x, pp1.y - p0.y);

  const double h00 = 2.0 * u3 - 3.0 * u2 + 1.0;
  const double h10 = u3 - 2.0 * u2 + u;
  const double h01 = -2.0 * u3 + 3.0 * u2;
  const double h11 = u3 - u2;

  const double x =
    h00 * p0.x + h10 * segment_length * t0.first + h01 * p1.x +
    h11 * segment_length * t1.first;
  const double y =
    h00 * p0.y + h10 * segment_length * t0.second + h01 * p1.y +
    h11 * segment_length * t1.second;

  const double dh00 = 6.0 * u2 - 6.0 * u;
  const double dh10 = 3.0 * u2 - 4.0 * u + 1.0;
  const double dh01 = -6.0 * u2 + 6.0 * u;
  const double dh11 = 3.0 * u2 - 2.0 * u;
  const double dx_du =
    dh00 * p0.x + dh10 * segment_length * t0.first + dh01 * p1.x +
    dh11 * segment_length * t1.first;
  const double dy_du =
    dh00 * p0.y + dh10 * segment_length * t0.second + dh01 * p1.y +
    dh11 * segment_length * t1.second;
  const double dx_ds = dx_du / segment_length;
  const double dy_ds = dy_du / segment_length;
  const double yaw = std::hypot(dx_ds, dy_ds) > 1.0e-6 ? std::atan2(dy_ds, dx_ds) :
    tf2::getYaw(path.poses[i1].pose.orientation);

  Reference ref;
  ref.x = x;
  ref.y = y;
  ref.yaw = yaw;
  ref.vx = reference_speed * dx_ds;
  ref.vy = reference_speed * dy_ds;
  return ref;
}

OmniMpcPursuitController::Reference OmniMpcPursuitController::getTrajectoryReferenceAtTime(
  const std::vector<TrajectoryPoint> & trajectory, double target_time) const
{
  if (trajectory.empty()) {
    return {};
  }
  if (trajectory.size() == 1 || target_time <= trajectory.front().time) {
    const auto & p = trajectory.front();
    return {p.x, p.y, p.yaw, p.vx, p.vy, p.wz, p.ax, p.ay};
  }
  if (target_time >= trajectory.back().time) {
    const auto & p = trajectory.back();
    return {p.x, p.y, p.yaw, p.vx, p.vy, p.wz, p.ax, p.ay};
  }

  for (size_t i = 1; i < trajectory.size(); ++i) {
    if (trajectory[i].time >= target_time) {
      const auto & prev = trajectory[i - 1];
      const auto & next = trajectory[i];
      const double dt = std::max(1.0e-6, next.time - prev.time);
      const double ratio = clampValue((target_time - prev.time) / dt, 0.0, 1.0);
      const double yaw_delta = normalizeAngle(next.yaw - prev.yaw);

      Reference ref;
      ref.x = prev.x + ratio * (next.x - prev.x);
      ref.y = prev.y + ratio * (next.y - prev.y);
      ref.yaw = normalizeAngle(prev.yaw + ratio * yaw_delta);
      ref.vx = prev.vx + ratio * (next.vx - prev.vx);
      ref.vy = prev.vy + ratio * (next.vy - prev.vy);
      ref.wz = prev.wz + ratio * (next.wz - prev.wz);
      ref.ax = prev.ax + ratio * (next.ax - prev.ax);
      ref.ay = prev.ay + ratio * (next.ay - prev.ay);
      return ref;
    }
  }

  const auto & p = trajectory.back();
  return {p.x, p.y, p.yaw, p.vx, p.vy, p.wz, p.ax, p.ay};
}

std::vector<OmniMpcPursuitController::TrajectoryPoint>
OmniMpcPursuitController::buildTimedTrajectory(
  const nav_msgs::msg::Path & transformed_plan, bool & valid) const
{
  valid = false;
  nav_msgs::msg::Path path = transformed_plan;
  if (path.poses.empty()) {
    return {};
  }

  geometry_msgs::msg::PoseStamped start_pose;
  start_pose.header = path.header;
  start_pose.pose.position.x = 0.0;
  start_pose.pose.position.y = 0.0;
  start_pose.pose.position.z = 0.0;
  tf2::Quaternion start_q;
  start_q.setRPY(0.0, 0.0, 0.0);
  start_pose.pose.orientation = tf2::toMsg(start_q);

  if (std::hypot(path.poses.front().pose.position.x, path.poses.front().pose.position.y) > 0.05) {
    path.poses.insert(path.poses.begin(), start_pose);
  }

  nav_msgs::msg::Path filtered_path;
  filtered_path.header = path.header;
  filtered_path.poses.reserve(path.poses.size());
  for (const auto & pose : path.poses) {
    if (filtered_path.poses.empty()) {
      filtered_path.poses.push_back(pose);
      continue;
    }
    const auto & prev = filtered_path.poses.back().pose.position;
    const auto & curr = pose.pose.position;
    if (std::hypot(curr.x - prev.x, curr.y - prev.y) >= 0.03) {
      filtered_path.poses.push_back(pose);
    }
  }

  if (filtered_path.poses.size() < 2) {
    return {};
  }

  const auto cumulative_distances = calculateCumulativeDistances(filtered_path);
  const double path_length = getPathLength(cumulative_distances);
  const double speed = trajectorySpeedLimit();
  if (path_length < 1.0e-4 || speed < 1.0e-4) {
    return {};
  }

  const double horizon_time = std::max(model_dt_ * static_cast<double>(horizon_steps_), minco_sample_dt_);
  const double total_time = std::max(path_length / speed, horizon_time);
  const size_t max_samples = 240;
  const size_t sample_count =
    std::min(max_samples, static_cast<size_t>(std::ceil(total_time / minco_sample_dt_)) + 1);

  std::vector<TrajectoryPoint> trajectory;
  trajectory.reserve(sample_count);
  for (size_t i = 0; i < sample_count; ++i) {
    const double time = std::min(total_time, static_cast<double>(i) * minco_sample_dt_);
    const double distance = std::min(path_length, speed * time);
    const auto ref =
      getSmoothedReferenceAtDistance(filtered_path, cumulative_distances, distance, speed);

    TrajectoryPoint point;
    point.time = time;
    point.x = ref.x;
    point.y = ref.y;
    point.yaw = ref.yaw;
    point.vx = clampValue(ref.vx, -max_vx_, max_vx_);
    point.vy = clampValue(ref.vy, -max_vy_, max_vy_);
    trajectory.push_back(point);
  }

  for (size_t i = 1; i < trajectory.size(); ++i) {
    auto & prev = trajectory[i - 1];
    auto & curr = trajectory[i];
    const double dt = std::max(1.0e-6, curr.time - prev.time);
    const double yaw_delta = normalizeAngle(curr.yaw - prev.yaw);
    curr.wz = clampValue(yaw_delta / dt, -max_wz_, max_wz_);
    curr.ax = clampValue((curr.vx - prev.vx) / dt, -max_ax_, max_ax_);
    curr.ay = clampValue((curr.vy - prev.vy) / dt, -max_ay_, max_ay_);
  }
  for (size_t i = 2; i < trajectory.size(); ++i) {
    auto & prev = trajectory[i - 1];
    auto & curr = trajectory[i];
    const double dt = std::max(1.0e-6, curr.time - prev.time);
    curr.wz = clampValue(curr.wz, prev.wz - max_awz_ * dt, prev.wz + max_awz_ * dt);
    curr.ax = clampValue(curr.ax, prev.ax - max_jerk_ * dt, prev.ax + max_jerk_ * dt);
    curr.ay = clampValue(curr.ay, prev.ay - max_jerk_ * dt, prev.ay + max_jerk_ * dt);
  }
  if (trajectory.size() > 1) {
    trajectory.front().wz = trajectory[1].wz;
    trajectory.front().ax = trajectory[1].ax;
    trajectory.front().ay = trajectory[1].ay;
  }

  valid = true;
  return trajectory;
}

std::vector<double> OmniMpcPursuitController::sampleRange(
  double lower, double upper, int samples) const
{
  if (upper < lower) {
    std::swap(lower, upper);
  }

  if (samples <= 1 || std::abs(upper - lower) < 1.0e-9) {
    return {0.5 * (lower + upper)};
  }

  std::vector<double> values;
  values.reserve(samples);
  const double step = (upper - lower) / static_cast<double>(samples - 1);
  for (int i = 0; i < samples; ++i) {
    values.push_back(lower + step * static_cast<double>(i));
  }
  return values;
}

OmniMpcPursuitController::Command OmniMpcPursuitController::chooseBestCommand(
  const nav_msgs::msg::Path & transformed_plan, const geometry_msgs::msg::Twist & velocity,
  const std::vector<TrajectoryPoint> * timed_trajectory, bool & solve_timed_out)
{
  solve_timed_out = false;
  Command previous_cmd = have_last_cmd_
                           ? last_cmd_
                           : Command{velocity.linear.x, velocity.linear.y, velocity.angular.z};
  previous_cmd.vx = clampValue(previous_cmd.vx, vx_min_, vx_max_);
  previous_cmd.vy = clampValue(previous_cmd.vy, vy_min_, vy_max_);
  previous_cmd.wz = clampValue(previous_cmd.wz, wz_min_, wz_max_);

  const auto vx_values = sampleRange(
    std::max(vx_min_, previous_cmd.vx - ax_max_ * control_duration_),
    std::min(vx_max_, previous_cmd.vx + ax_max_ * control_duration_), vx_samples_);
  const auto vy_values = sampleRange(
    std::max(vy_min_, previous_cmd.vy - ay_max_ * control_duration_),
    std::min(vy_max_, previous_cmd.vy + ay_max_ * control_duration_), vy_samples_);
  const auto wz_values = sampleRange(
    std::max(wz_min_, previous_cmd.wz - az_max_ * control_duration_),
    std::min(wz_max_, previous_cmd.wz + az_max_ * control_duration_), wz_samples_);

  const auto cumulative_distances = calculateCumulativeDistances(transformed_plan);
  double best_score = std::numeric_limits<double>::infinity();
  Command best_command{};
  bool found_valid_command = false;
  const auto solve_start = std::chrono::steady_clock::now();

  for (const auto vx : vx_values) {
    for (const auto vy : vy_values) {
      for (const auto wz : wz_values) {
        const auto now = std::chrono::steady_clock::now();
        const double elapsed_ms =
          std::chrono::duration<double, std::milli>(now - solve_start).count();
        if (elapsed_ms > max_solve_time_ms_) {
          solve_timed_out = true;
          break;
        }

        const Command command{vx, vy, wz};
        bool collision_free = true;
        const double score = scoreCommand(
          command, transformed_plan, cumulative_distances, timed_trajectory, previous_cmd,
          collision_free);
        if (collision_free && score < best_score) {
          best_score = score;
          best_command = command;
          found_valid_command = true;
        }
      }
      if (solve_timed_out) {
        break;
      }
    }
    if (solve_timed_out) {
      break;
    }
  }

  if (!found_valid_command) {
    RCLCPP_WARN_THROTTLE(
      logger_, *clock_, 1000, "MPC found no collision-free candidate. Commanding zero velocity.");
    return Command{};
  }

  return best_command;
}

double OmniMpcPursuitController::scoreCommand(
  const Command & command, const nav_msgs::msg::Path & transformed_plan,
  const std::vector<double> & cumulative_distances,
  const std::vector<TrajectoryPoint> * timed_trajectory,
  const Command & previous_command, bool & collision_free) const
{
  State state;
  double cost = r_control_ * (command.vx * command.vx + command.vy * command.vy +
                              0.25 * command.wz * command.wz);
  cost += r_delta_control_ *
          ((command.vx - previous_command.vx) * (command.vx - previous_command.vx) +
           (command.vy - previous_command.vy) * (command.vy - previous_command.vy) +
           0.25 * (command.wz - previous_command.wz) * (command.wz - previous_command.wz));

  for (int step = 1; step <= horizon_steps_; ++step) {
    state = predictNextState(state, command);
    if ((step % collision_check_step_ == 0 || step == horizon_steps_) && !isStateCollisionFree(state)) {
      collision_free = false;
      return std::numeric_limits<double>::infinity();
    }

    Reference ref;
    if (timed_trajectory != nullptr) {
      ref = getTrajectoryReferenceAtTime(*timed_trajectory, model_dt_ * static_cast<double>(step));
    } else {
      const double target_distance =
        std::min(lookahead_dist_, reference_speed_ * model_dt_ * static_cast<double>(step));
      ref = getReferenceAtDistance(transformed_plan, cumulative_distances, target_distance);
    }

    const double dx = state.x - ref.x;
    const double dy = state.y - ref.y;
    const double cos_yaw = std::cos(ref.yaw);
    const double sin_yaw = std::sin(ref.yaw);
    const double longitudinal_error = cos_yaw * dx + sin_yaw * dy;
    const double lateral_error = -sin_yaw * dx + cos_yaw * dy;
    const double yaw_error = normalizeAngle(state.yaw - ref.yaw);
    const double terminal_scale = step == horizon_steps_ ? q_terminal_ : 1.0;

    cost += terminal_scale *
            (q_path_x_ * longitudinal_error * longitudinal_error +
             q_path_y_ * lateral_error * lateral_error + q_yaw_ * yaw_error * yaw_error);

    if (timed_trajectory != nullptr) {
      const double predicted_vx =
        std::cos(state.yaw) * command.vx - std::sin(state.yaw) * command.vy;
      const double predicted_vy =
        std::sin(state.yaw) * command.vx + std::cos(state.yaw) * command.vy;
      const double velocity_error_x = predicted_vx - ref.vx;
      const double velocity_error_y = predicted_vy - ref.vy;
      const double yaw_rate_error = command.wz - ref.wz;
      cost += terminal_scale * q_velocity_ *
              (velocity_error_x * velocity_error_x + velocity_error_y * velocity_error_y +
               0.25 * yaw_rate_error * yaw_rate_error);
    }
  }

  collision_free = true;
  return cost;
}

OmniMpcPursuitController::State OmniMpcPursuitController::predictNextState(
  const State & state, const Command & command) const
{
  State next;
  next.x = state.x + model_dt_ * (std::cos(state.yaw) * command.vx - std::sin(state.yaw) * command.vy);
  next.y = state.y + model_dt_ * (std::sin(state.yaw) * command.vx + std::cos(state.yaw) * command.vy);
  next.yaw = normalizeAngle(state.yaw + model_dt_ * command.wz);
  return next;
}

bool OmniMpcPursuitController::isStateCollisionFree(const State & state) const
{
  geometry_msgs::msg::PoseStamped local_pose;
  geometry_msgs::msg::PoseStamped costmap_pose;
  local_pose.header.frame_id = costmap_ros_->getBaseFrameID();
  local_pose.header.stamp.sec = 0;
  local_pose.header.stamp.nanosec = 0;
  local_pose.pose.position.x = state.x;
  local_pose.pose.position.y = state.y;
  local_pose.pose.position.z = 0.0;
  tf2::Quaternion q;
  q.setRPY(0.0, 0.0, state.yaw);
  local_pose.pose.orientation = tf2::toMsg(q);

  if (!transformPose(costmap_ros_->getGlobalFrameID(), local_pose, costmap_pose)) {
    return false;
  }

  unsigned int mx = 0;
  unsigned int my = 0;
  if (!costmap_->worldToMap(costmap_pose.pose.position.x, costmap_pose.pose.position.y, mx, my)) {
    return false;
  }

  return costmap_->getCost(mx, my) < nav2_costmap_2d::INSCRIBED_INFLATED_OBSTACLE;
}

geometry_msgs::msg::TwistStamped OmniMpcPursuitController::makeCommandMsg(
  const geometry_msgs::msg::PoseStamped & pose, const Command & command) const
{
  geometry_msgs::msg::TwistStamped cmd_vel;
  cmd_vel.header = pose.header;
  cmd_vel.twist.linear.x = command.vx;
  cmd_vel.twist.linear.y = command.vy;
  cmd_vel.twist.angular.z = command.wz;
  return cmd_vel;
}

geometry_msgs::msg::TwistStamped OmniMpcPursuitController::makeZeroCommand(
  const geometry_msgs::msg::PoseStamped & pose) const
{
  return makeCommandMsg(pose, Command{});
}

double OmniMpcPursuitController::normalizeAngle(double angle) const
{
  return std::atan2(std::sin(angle), std::cos(angle));
}

double OmniMpcPursuitController::clampValue(double value, double lower, double upper) const
{
  if (upper < lower) {
    std::swap(lower, upper);
  }
  return std::min(std::max(value, lower), upper);
}

double OmniMpcPursuitController::getPathLength(
  const std::vector<double> & cumulative_distances) const
{
  return cumulative_distances.empty() ? 0.0 : cumulative_distances.back();
}

double OmniMpcPursuitController::trajectorySpeedLimit() const
{
  const double translational_limit = std::hypot(max_vx_, max_vy_);
  return clampValue(reference_speed_, 0.05, translational_limit);
}

void OmniMpcPursuitController::publishTimedTrajectory(
  const std::vector<TrajectoryPoint> & trajectory, const std_msgs::msg::Header & header) const
{
  if (!minco_trajectory_path_pub_ || !minco_trajectory_path_pub_->is_activated()) {
    return;
  }

  nav_msgs::msg::Path path;
  path.header = header;
  path.poses.reserve(trajectory.size());
  for (const auto & point : trajectory) {
    geometry_msgs::msg::PoseStamped pose;
    pose.header = header;
    pose.pose.position.x = point.x;
    pose.pose.position.y = point.y;
    pose.pose.position.z = 0.0;
    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, point.yaw);
    pose.pose.orientation = tf2::toMsg(q);
    path.poses.push_back(pose);
  }
  minco_trajectory_path_pub_->publish(path);
}

void OmniMpcPursuitController::publishTrajectoryMarkers(
  const std::vector<TrajectoryPoint> & trajectory, const std_msgs::msg::Header & header) const
{
  if (!minco_trajectory_markers_pub_ || !minco_trajectory_markers_pub_->is_activated()) {
    return;
  }

  visualization_msgs::msg::MarkerArray markers;

  visualization_msgs::msg::Marker clear_marker;
  clear_marker.header = header;
  clear_marker.ns = "minco_trajectory";
  clear_marker.id = 0;
  clear_marker.action = visualization_msgs::msg::Marker::DELETEALL;
  markers.markers.push_back(clear_marker);

  visualization_msgs::msg::Marker point_marker;
  point_marker.header = header;
  point_marker.ns = "minco_trajectory";
  point_marker.id = 1;
  point_marker.type = visualization_msgs::msg::Marker::SPHERE_LIST;
  point_marker.action = visualization_msgs::msg::Marker::ADD;
  point_marker.pose.orientation.w = 1.0;
  point_marker.scale.x = 0.06;
  point_marker.scale.y = 0.06;
  point_marker.scale.z = 0.06;
  point_marker.color.r = 0.1;
  point_marker.color.g = 0.8;
  point_marker.color.b = 1.0;
  point_marker.color.a = 0.85;
  point_marker.points.reserve(trajectory.size());

  for (const auto & point : trajectory) {
    geometry_msgs::msg::Point marker_point;
    marker_point.x = point.x;
    marker_point.y = point.y;
    marker_point.z = 0.03;
    point_marker.points.push_back(marker_point);
  }
  markers.markers.push_back(point_marker);

  minco_trajectory_markers_pub_->publish(markers);
}

void OmniMpcPursuitController::publishDebug(
  const std::string & mode, bool fallback, bool solve_timed_out, double build_ms,
  double solve_ms, size_t trajectory_points) const
{
  if (!minco_debug_pub_ || !minco_debug_pub_->is_activated()) {
    return;
  }

  std_msgs::msg::String msg;
  std::ostringstream stream;
  stream << "controller=" << plugin_name_ << " mode=" << mode
         << " fallback=" << (fallback ? "true" : "false")
         << " solve_timed_out=" << (solve_timed_out ? "true" : "false")
         << " build_ms=" << build_ms << " solve_ms=" << solve_ms
         << " trajectory_points=" << trajectory_points << " max_solve_time_ms="
         << max_solve_time_ms_ << " trajectory_timeout=" << trajectory_timeout_;
  msg.data = stream.str();
  minco_debug_pub_->publish(msg);
}

}  // namespace pb_omni_pid_pursuit_controller

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(
  pb_omni_pid_pursuit_controller::OmniMpcPursuitController, nav2_core::Controller)
