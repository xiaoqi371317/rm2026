// Copyright 2025 Lihan Chen
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef PB_OMNI_PID_PURSUIT_CONTROLLER__OMNI_MPC_PURSUIT_CONTROLLER_HPP_
#define PB_OMNI_PID_PURSUIT_CONTROLLER__OMNI_MPC_PURSUIT_CONTROLLER_HPP_

#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "nav2_core/controller.hpp"
#include "nav2_costmap_2d/costmap_2d_ros.hpp"
#include "nav_msgs/msg/path.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_publisher.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "std_msgs/msg/header.hpp"
#include "std_msgs/msg/string.hpp"
#include "tf2/time.h"
#include "tf2_ros/buffer.h"
#include "visualization_msgs/msg/marker_array.hpp"

namespace pb_omni_pid_pursuit_controller
{

class OmniMpcPursuitController : public nav2_core::Controller
{
public:
  OmniMpcPursuitController() = default;
  ~OmniMpcPursuitController() override = default;

  void configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent, std::string name,
    std::shared_ptr<tf2_ros::Buffer> tf,
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) override;

  void cleanup() override;
  void activate() override;
  void deactivate() override;

  geometry_msgs::msg::TwistStamped computeVelocityCommands(
    const geometry_msgs::msg::PoseStamped & pose, const geometry_msgs::msg::Twist & velocity,
    nav2_core::GoalChecker * goal_checker) override;

  void setPlan(const nav_msgs::msg::Path & path) override;
  void setSpeedLimit(const double & speed_limit, const bool & percentage) override;

private:
  struct Command
  {
    double vx{0.0};
    double vy{0.0};
    double wz{0.0};
  };

  struct State
  {
    double x{0.0};
    double y{0.0};
    double yaw{0.0};
  };

  struct Reference
  {
    double x{0.0};
    double y{0.0};
    double yaw{0.0};
    double vx{0.0};
    double vy{0.0};
    double wz{0.0};
    double ax{0.0};
    double ay{0.0};
  };

  struct TrajectoryPoint
  {
    double time{0.0};
    double x{0.0};
    double y{0.0};
    double yaw{0.0};
    double vx{0.0};
    double vy{0.0};
    double wz{0.0};
    double ax{0.0};
    double ay{0.0};
  };

  nav_msgs::msg::Path transformGlobalPlan(const geometry_msgs::msg::PoseStamped & pose);

  bool transformPose(
    const std::string & frame, const geometry_msgs::msg::PoseStamped & in_pose,
    geometry_msgs::msg::PoseStamped & out_pose) const;

  double getCostmapMaxExtent() const;
  std::vector<double> calculateCumulativeDistances(const nav_msgs::msg::Path & path) const;
  Reference getReferenceAtDistance(
    const nav_msgs::msg::Path & path, const std::vector<double> & cumulative_distances,
    double target_distance) const;
  Reference getSmoothedReferenceAtDistance(
    const nav_msgs::msg::Path & path, const std::vector<double> & cumulative_distances,
    double target_distance, double reference_speed) const;
  Reference makeReferenceFromSegment(
    const geometry_msgs::msg::PoseStamped & start, const geometry_msgs::msg::PoseStamped & end,
    double ratio) const;
  Reference makeSmoothedReferenceFromSegment(
    const nav_msgs::msg::Path & path, const std::vector<double> & cumulative_distances,
    size_t segment_index, double ratio, double reference_speed) const;
  Reference getTrajectoryReferenceAtTime(
    const std::vector<TrajectoryPoint> & trajectory, double target_time) const;
  std::vector<TrajectoryPoint> buildTimedTrajectory(
    const nav_msgs::msg::Path & transformed_plan, bool & valid) const;

  std::vector<double> sampleRange(double lower, double upper, int samples) const;
  Command chooseBestCommand(
    const nav_msgs::msg::Path & transformed_plan, const geometry_msgs::msg::Twist & velocity,
    const std::vector<TrajectoryPoint> * timed_trajectory, bool & solve_timed_out);
  double scoreCommand(
    const Command & command, const nav_msgs::msg::Path & transformed_plan,
    const std::vector<double> & cumulative_distances,
    const std::vector<TrajectoryPoint> * timed_trajectory,
    const Command & previous_command, bool & collision_free) const;

  State predictNextState(const State & state, const Command & command) const;
  bool isStateCollisionFree(const State & state) const;
  geometry_msgs::msg::TwistStamped makeCommandMsg(
    const geometry_msgs::msg::PoseStamped & pose, const Command & command) const;
  geometry_msgs::msg::TwistStamped makeZeroCommand(
    const geometry_msgs::msg::PoseStamped & pose) const;

  double normalizeAngle(double angle) const;
  double clampValue(double value, double lower, double upper) const;
  double getPathLength(const std::vector<double> & cumulative_distances) const;
  double trajectorySpeedLimit() const;
  void publishTimedTrajectory(
    const std::vector<TrajectoryPoint> & trajectory, const std_msgs::msg::Header & header) const;
  void publishTrajectoryMarkers(
    const std::vector<TrajectoryPoint> & trajectory, const std_msgs::msg::Header & header) const;
  void publishDebug(
    const std::string & mode, bool fallback, bool solve_timed_out, double build_ms,
    double solve_ms, size_t trajectory_points) const;

  rclcpp_lifecycle::LifecycleNode::WeakPtr node_;
  std::shared_ptr<tf2_ros::Buffer> tf_;
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros_;
  nav2_costmap_2d::Costmap2D * costmap_{nullptr};
  std::string plugin_name_;
  rclcpp::Logger logger_{rclcpp::get_logger("OmniMpcPursuitController")};
  rclcpp::Clock::SharedPtr clock_;
  mutable std::mutex mutex_;

  nav_msgs::msg::Path global_plan_;
  Command last_cmd_;
  bool have_last_cmd_{false};
  rclcpp_lifecycle::LifecyclePublisher<nav_msgs::msg::Path>::SharedPtr
    minco_trajectory_path_pub_;
  rclcpp_lifecycle::LifecyclePublisher<visualization_msgs::msg::MarkerArray>::SharedPtr
    minco_trajectory_markers_pub_;
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::String>::SharedPtr minco_debug_pub_;

  tf2::Duration transform_tolerance_{tf2::durationFromSec(0.2)};
  double control_duration_{0.05};
  double max_robot_pose_search_dist_{3.0};

  int horizon_steps_{12};
  double model_dt_{0.05};
  double reference_speed_{0.8};
  double lookahead_dist_{0.8};

  double vx_min_{-0.2};
  double vx_max_{1.2};
  double vy_min_{-0.45};
  double vy_max_{0.45};
  double wz_min_{-2.2};
  double wz_max_{2.2};

  double ax_max_{2.0};
  double ay_max_{2.0};
  double az_max_{3.0};

  int vx_samples_{7};
  int vy_samples_{7};
  int wz_samples_{9};

  double q_path_x_{2.0};
  double q_path_y_{12.0};
  double q_yaw_{6.0};
  double q_terminal_{3.0};
  double q_velocity_{0.8};
  double r_control_{0.2};
  double r_delta_control_{2.0};

  int collision_check_step_{2};

  bool use_minco_trajectory_{true};
  bool fallback_to_path_mpc_{true};
  double trajectory_timeout_{0.3};
  double max_solve_time_ms_{20.0};
  double max_vx_{1.2};
  double max_vy_{0.45};
  double max_wz_{2.2};
  double max_ax_{2.0};
  double max_ay_{2.0};
  double max_awz_{3.0};
  double max_jerk_{8.0};
  double minco_sample_dt_{0.05};
};

}  // namespace pb_omni_pid_pursuit_controller

#endif  // PB_OMNI_PID_PURSUIT_CONTROLLER__OMNI_MPC_PURSUIT_CONTROLLER_HPP_
